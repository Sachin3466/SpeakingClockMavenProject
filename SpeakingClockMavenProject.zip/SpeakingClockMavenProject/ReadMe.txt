#This Project will read time in digits to words

#Port is set to 8081

#Get method for current Time is as below
http://localhost:8081/speakingclock/currentTimeWords

#Pass time as Path Variable from postMan ex: time = 12:00
http://localhost:8081/speakingclock/words/time/:time